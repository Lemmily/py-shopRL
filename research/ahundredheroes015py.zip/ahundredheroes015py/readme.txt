
 100 Heroes: Shopkeeper of Doom v0.15
 Copyright (c) 2013 Paul Wright
 All rights reserved.

Programmed in Python, with Libtcod 1.5.0 Python Wrapper by Jice.

Thanks to:
Bay12 Forums (especially Neonivek for lots of ideas)
Jotaf (for Roguelike Tutorial, which got this started)
Jice (for the excellent Python Wrapper for Libtcod)

For full license details please refer to LICENSE.txt

For more help, try ? in-game, or read the MANUAL.txt.
